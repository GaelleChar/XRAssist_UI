
using UnityEngine;
using Unity.Collections;
using System.Collections;
using UnityEngine.SceneManagement;
using Unity.Burst;
using Unity.Jobs;
/*
public class LoadLevel : MonoBehaviour
{
    /*TODO: 
    Allow buttons to trigger next scene
    */
    /*
    public bool loadLevel;
    public string levelName;

    private NativeArray<JobHandle> nativeHandles;

    [SerializeField]
    private int iterations;

    void Start(){
        
        iterations = 1;
    }
    void Update(){

        LoadNextLevel();
    }

    public JobHandle CreateJobHandle()
    {
        var job = new TestJob();
        return job.Schedule();
    }

    [BurstCompile]
    public struct TestJob : IJob
    {
        public void Execute(){
            LoadLevel test = new LoadLevel();
            Debug.Log("Executing Load Next Level");
            test.LoadNextLevel();
           // LoadNextLevel();
        }

    }

    
    private IEnumerator LoadAsyncLevel(){
        var progress = SceneManager.LoadSceneAsync(levelName, LoadSceneMode.Additive);

        while(!progress.isDone){
            yield return null;
        }
        Debug.Log("level loaded");
    }

    void LoadNextLevel(){
        if(loadLevel == true){
            nativeHandles = new NativeArray<JobHandle>(iterations, Allocator.Temp);

            for (int i = 0; i < iterations; ++i)
            {
                nativeHandles[i] = CreateJobHandle();
            }

            JobHandle.CompleteAll(nativeHandles);
            loadLevel = false;
            SceneManager.LoadScene(levelName, LoadSceneMode.Additive);

            //StartCoroutine(LoadAsyncLevel());
        }

    }
}
*/